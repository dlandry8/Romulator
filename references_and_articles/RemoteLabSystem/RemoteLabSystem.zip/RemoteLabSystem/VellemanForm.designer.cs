﻿namespace Velleman
{
    partial class VellemanForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RadioButton13 = new System.Windows.Forms.RadioButton();
            this.RadioButton7 = new System.Windows.Forms.RadioButton();
            this.RadioButton14 = new System.Windows.Forms.RadioButton();
            this.RadioButton19 = new System.Windows.Forms.RadioButton();
            this.RadioButton22 = new System.Windows.Forms.RadioButton();
            this.GroupBox9 = new System.Windows.Forms.GroupBox();
            this.u2 = new System.Windows.Forms.RadioButton();
            this.u5 = new System.Windows.Forms.RadioButton();
            this.u10 = new System.Windows.Forms.RadioButton();
            this.u20 = new System.Windows.Forms.RadioButton();
            this.u50 = new System.Windows.Forms.RadioButton();
            this.m01 = new System.Windows.Forms.RadioButton();
            this.m02 = new System.Windows.Forms.RadioButton();
            this.m05 = new System.Windows.Forms.RadioButton();
            this.m1 = new System.Windows.Forms.RadioButton();
            this.m2 = new System.Windows.Forms.RadioButton();
            this.m5 = new System.Windows.Forms.RadioButton();
            this.m10 = new System.Windows.Forms.RadioButton();
            this.m20 = new System.Windows.Forms.RadioButton();
            this.m50 = new System.Windows.Forms.RadioButton();
            this.m100 = new System.Windows.Forms.RadioButton();
            this.m200 = new System.Windows.Forms.RadioButton();
            this.m500 = new System.Windows.Forms.RadioButton();
            this.RadioButton23 = new System.Windows.Forms.RadioButton();
            this.TrackBar3 = new System.Windows.Forms.TrackBar();
            this.RadioButton21 = new System.Windows.Forms.RadioButton();
            this.RadioButton24 = new System.Windows.Forms.RadioButton();
            this.RadioButton20 = new System.Windows.Forms.RadioButton();
            this.Label3 = new System.Windows.Forms.Label();
            this.RadioButton16 = new System.Windows.Forms.RadioButton();
            this.Label2 = new System.Windows.Forms.Label();
            this.RadioButton15 = new System.Windows.Forms.RadioButton();
            this.RadioButton17 = new System.Windows.Forms.RadioButton();
            this.RadioButton18 = new System.Windows.Forms.RadioButton();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.TrackBar2 = new System.Windows.Forms.TrackBar();
            this.TrackBar1 = new System.Windows.Forms.TrackBar();
            this.GroupBox7 = new System.Windows.Forms.GroupBox();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.GroupBox8 = new System.Windows.Forms.GroupBox();
            this.GroupBox6 = new System.Windows.Forms.GroupBox();
            this.GroupBox5 = new System.Windows.Forms.GroupBox();
            this.RadioButton8 = new System.Windows.Forms.RadioButton();
            this.RadioButton9 = new System.Windows.Forms.RadioButton();
            this.RadioButton10 = new System.Windows.Forms.RadioButton();
            this.RadioButton11 = new System.Windows.Forms.RadioButton();
            this.RadioButton12 = new System.Windows.Forms.RadioButton();
            this.Button8 = new System.Windows.Forms.Button();
            this.GroupBox4 = new System.Windows.Forms.GroupBox();
            this.Label11 = new System.Windows.Forms.Label();
            this.Label17 = new System.Windows.Forms.Label();
            this.TextBox7 = new System.Windows.Forms.TextBox();
            this.Label15 = new System.Windows.Forms.Label();
            this.Label16 = new System.Windows.Forms.Label();
            this.TextBox6 = new System.Windows.Forms.TextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.Label14 = new System.Windows.Forms.Label();
            this.TextBox5 = new System.Windows.Forms.TextBox();
            this.Label12 = new System.Windows.Forms.Label();
            this.TextBox4 = new System.Windows.Forms.TextBox();
            this.RadioButton47 = new System.Windows.Forms.RadioButton();
            this.RadioButton46 = new System.Windows.Forms.RadioButton();
            this.RadioButton45 = new System.Windows.Forms.RadioButton();
            this.RadioButton44 = new System.Windows.Forms.RadioButton();
            this.RadioButton43 = new System.Windows.Forms.RadioButton();
            this.RadioButton42 = new System.Windows.Forms.RadioButton();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label10 = new System.Windows.Forms.Label();
            this.TextBox3 = new System.Windows.Forms.TextBox();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.TextBox2 = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.Button1 = new System.Windows.Forms.Button();
            this.RadioButton6 = new System.Windows.Forms.RadioButton();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.RadioButton5 = new System.Windows.Forms.RadioButton();
            this.RadioButton4 = new System.Windows.Forms.RadioButton();
            this.RadioButton3 = new System.Windows.Forms.RadioButton();
            this.RadioButton2 = new System.Windows.Forms.RadioButton();
            this.RadioButton1 = new System.Windows.Forms.RadioButton();
            this.Label1 = new System.Windows.Forms.Label();
            this.Button7 = new System.Windows.Forms.Button();
            this.Button4 = new System.Windows.Forms.Button();
            this.Button3 = new System.Windows.Forms.Button();
            this.Button2 = new System.Windows.Forms.Button();
            this.CheckBox1 = new System.Windows.Forms.CheckBox();
            this.Button6 = new System.Windows.Forms.Button();
            this.Button5 = new System.Windows.Forms.Button();
            this.ListBox1 = new System.Windows.Forms.ListBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.GroupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TrackBar3)).BeginInit();
            this.GroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TrackBar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrackBar1)).BeginInit();
            this.GroupBox7.SuspendLayout();
            this.GroupBox3.SuspendLayout();
            this.GroupBox8.SuspendLayout();
            this.GroupBox6.SuspendLayout();
            this.GroupBox5.SuspendLayout();
            this.GroupBox4.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // RadioButton13
            // 
            this.RadioButton13.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton13.AutoSize = true;
            this.RadioButton13.Location = new System.Drawing.Point(106, 19);
            this.RadioButton13.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton13.Name = "RadioButton13";
            this.RadioButton13.Size = new System.Drawing.Size(44, 23);
            this.RadioButton13.TabIndex = 3;
            this.RadioButton13.TabStop = true;
            this.RadioButton13.Tag = "2";
            this.RadioButton13.Text = "GND";
            this.RadioButton13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton13.UseVisualStyleBackColor = true;
            this.RadioButton13.CheckedChanged += new System.EventHandler(this.RadioButton13_CheckedChanged);
            // 
            // RadioButton7
            // 
            this.RadioButton7.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton7.AutoSize = true;
            this.RadioButton7.Location = new System.Drawing.Point(106, 48);
            this.RadioButton7.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton7.Name = "RadioButton7";
            this.RadioButton7.Size = new System.Drawing.Size(44, 23);
            this.RadioButton7.TabIndex = 6;
            this.RadioButton7.TabStop = true;
            this.RadioButton7.Tag = "5";
            this.RadioButton7.Text = "10mV";
            this.RadioButton7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton7.UseVisualStyleBackColor = true;
            this.RadioButton7.CheckedChanged += new System.EventHandler(this.RadioButton7_CheckedChanged);
            // 
            // RadioButton14
            // 
            this.RadioButton14.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton14.AutoSize = true;
            this.RadioButton14.Location = new System.Drawing.Point(56, 19);
            this.RadioButton14.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton14.Name = "RadioButton14";
            this.RadioButton14.Size = new System.Drawing.Size(44, 23);
            this.RadioButton14.TabIndex = 2;
            this.RadioButton14.TabStop = true;
            this.RadioButton14.Tag = "1";
            this.RadioButton14.Text = "DC";
            this.RadioButton14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton14.UseVisualStyleBackColor = true;
            this.RadioButton14.CheckedChanged += new System.EventHandler(this.RadioButton14_CheckedChanged);
            // 
            // RadioButton19
            // 
            this.RadioButton19.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton19.AutoSize = true;
            this.RadioButton19.Location = new System.Drawing.Point(56, 19);
            this.RadioButton19.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton19.Name = "RadioButton19";
            this.RadioButton19.Size = new System.Drawing.Size(44, 23);
            this.RadioButton19.TabIndex = 2;
            this.RadioButton19.TabStop = true;
            this.RadioButton19.Tag = "1";
            this.RadioButton19.Text = "CH2";
            this.RadioButton19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton19.UseVisualStyleBackColor = true;
            this.RadioButton19.CheckedChanged += new System.EventHandler(this.RadioButton19_CheckedChanged);
            // 
            // RadioButton22
            // 
            this.RadioButton22.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton22.AutoSize = true;
            this.RadioButton22.Location = new System.Drawing.Point(6, 19);
            this.RadioButton22.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton22.Name = "RadioButton22";
            this.RadioButton22.Size = new System.Drawing.Size(44, 23);
            this.RadioButton22.TabIndex = 1;
            this.RadioButton22.TabStop = true;
            this.RadioButton22.Tag = "0";
            this.RadioButton22.Text = "CH1";
            this.RadioButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton22.UseVisualStyleBackColor = true;
            this.RadioButton22.CheckedChanged += new System.EventHandler(this.RadioButton22_CheckedChanged);
            // 
            // GroupBox9
            // 
            this.GroupBox9.Controls.Add(this.u2);
            this.GroupBox9.Controls.Add(this.u5);
            this.GroupBox9.Controls.Add(this.u10);
            this.GroupBox9.Controls.Add(this.u20);
            this.GroupBox9.Controls.Add(this.u50);
            this.GroupBox9.Controls.Add(this.m01);
            this.GroupBox9.Controls.Add(this.m02);
            this.GroupBox9.Controls.Add(this.m05);
            this.GroupBox9.Controls.Add(this.m1);
            this.GroupBox9.Controls.Add(this.m2);
            this.GroupBox9.Controls.Add(this.m5);
            this.GroupBox9.Controls.Add(this.m10);
            this.GroupBox9.Controls.Add(this.m20);
            this.GroupBox9.Controls.Add(this.m50);
            this.GroupBox9.Controls.Add(this.m100);
            this.GroupBox9.Controls.Add(this.m200);
            this.GroupBox9.Controls.Add(this.m500);
            this.GroupBox9.Location = new System.Drawing.Point(542, 13);
            this.GroupBox9.Name = "GroupBox9";
            this.GroupBox9.Size = new System.Drawing.Size(156, 229);
            this.GroupBox9.TabIndex = 52;
            this.GroupBox9.TabStop = false;
            this.GroupBox9.Text = "Time/Div";
            // 
            // u2
            // 
            this.u2.Appearance = System.Windows.Forms.Appearance.Button;
            this.u2.Location = new System.Drawing.Point(55, 165);
            this.u2.MinimumSize = new System.Drawing.Size(44, 0);
            this.u2.Name = "u2";
            this.u2.Size = new System.Drawing.Size(44, 23);
            this.u2.TabIndex = 17;
            this.u2.TabStop = true;
            this.u2.Tag = "16";
            this.u2.Text = "2us";
            this.u2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.u2.UseVisualStyleBackColor = true;
            this.u2.CheckedChanged += new System.EventHandler(this.u2_CheckedChanged);
            // 
            // u5
            // 
            this.u5.Appearance = System.Windows.Forms.Appearance.Button;
            this.u5.Location = new System.Drawing.Point(6, 165);
            this.u5.MinimumSize = new System.Drawing.Size(44, 0);
            this.u5.Name = "u5";
            this.u5.Size = new System.Drawing.Size(44, 23);
            this.u5.TabIndex = 16;
            this.u5.TabStop = true;
            this.u5.Tag = "15";
            this.u5.Text = "5us";
            this.u5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.u5.UseVisualStyleBackColor = true;
            this.u5.CheckedChanged += new System.EventHandler(this.u5_CheckedChanged);
            // 
            // u10
            // 
            this.u10.Appearance = System.Windows.Forms.Appearance.Button;
            this.u10.Location = new System.Drawing.Point(106, 135);
            this.u10.MinimumSize = new System.Drawing.Size(44, 0);
            this.u10.Name = "u10";
            this.u10.Size = new System.Drawing.Size(44, 23);
            this.u10.TabIndex = 15;
            this.u10.TabStop = true;
            this.u10.Tag = "14";
            this.u10.Text = "10us";
            this.u10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.u10.UseVisualStyleBackColor = true;
            this.u10.CheckedChanged += new System.EventHandler(this.u10_CheckedChanged);
            // 
            // u20
            // 
            this.u20.Appearance = System.Windows.Forms.Appearance.Button;
            this.u20.Location = new System.Drawing.Point(55, 135);
            this.u20.MinimumSize = new System.Drawing.Size(44, 0);
            this.u20.Name = "u20";
            this.u20.Size = new System.Drawing.Size(44, 23);
            this.u20.TabIndex = 14;
            this.u20.TabStop = true;
            this.u20.Tag = "13";
            this.u20.Text = "20us";
            this.u20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.u20.UseVisualStyleBackColor = true;
            this.u20.CheckedChanged += new System.EventHandler(this.u20_CheckedChanged);
            // 
            // u50
            // 
            this.u50.Appearance = System.Windows.Forms.Appearance.Button;
            this.u50.Location = new System.Drawing.Point(6, 135);
            this.u50.MinimumSize = new System.Drawing.Size(44, 0);
            this.u50.Name = "u50";
            this.u50.Size = new System.Drawing.Size(44, 23);
            this.u50.TabIndex = 13;
            this.u50.TabStop = true;
            this.u50.Tag = "12";
            this.u50.Text = "50us";
            this.u50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.u50.UseVisualStyleBackColor = true;
            this.u50.CheckedChanged += new System.EventHandler(this.u50_CheckedChanged);
            // 
            // m01
            // 
            this.m01.Appearance = System.Windows.Forms.Appearance.Button;
            this.m01.Location = new System.Drawing.Point(106, 106);
            this.m01.MinimumSize = new System.Drawing.Size(44, 0);
            this.m01.Name = "m01";
            this.m01.Size = new System.Drawing.Size(44, 23);
            this.m01.TabIndex = 12;
            this.m01.TabStop = true;
            this.m01.Tag = "11";
            this.m01.Text = "0.1ms";
            this.m01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.m01.UseVisualStyleBackColor = true;
            this.m01.CheckedChanged += new System.EventHandler(this.m01_CheckedChanged);
            // 
            // m02
            // 
            this.m02.Appearance = System.Windows.Forms.Appearance.Button;
            this.m02.Location = new System.Drawing.Point(55, 106);
            this.m02.MinimumSize = new System.Drawing.Size(44, 0);
            this.m02.Name = "m02";
            this.m02.Size = new System.Drawing.Size(44, 23);
            this.m02.TabIndex = 11;
            this.m02.TabStop = true;
            this.m02.Tag = "10";
            this.m02.Text = "0.2ms";
            this.m02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.m02.UseVisualStyleBackColor = true;
            this.m02.CheckedChanged += new System.EventHandler(this.m02_CheckedChanged);
            // 
            // m05
            // 
            this.m05.Appearance = System.Windows.Forms.Appearance.Button;
            this.m05.Location = new System.Drawing.Point(6, 106);
            this.m05.MinimumSize = new System.Drawing.Size(44, 0);
            this.m05.Name = "m05";
            this.m05.Size = new System.Drawing.Size(44, 23);
            this.m05.TabIndex = 10;
            this.m05.TabStop = true;
            this.m05.Tag = "9";
            this.m05.Text = "0.5ms";
            this.m05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.m05.UseVisualStyleBackColor = true;
            this.m05.CheckedChanged += new System.EventHandler(this.m05_CheckedChanged);
            // 
            // m1
            // 
            this.m1.Appearance = System.Windows.Forms.Appearance.Button;
            this.m1.Location = new System.Drawing.Point(106, 77);
            this.m1.MinimumSize = new System.Drawing.Size(44, 0);
            this.m1.Name = "m1";
            this.m1.Size = new System.Drawing.Size(44, 23);
            this.m1.TabIndex = 9;
            this.m1.TabStop = true;
            this.m1.Tag = "8";
            this.m1.Text = "1ms";
            this.m1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.m1.UseVisualStyleBackColor = true;
            this.m1.CheckedChanged += new System.EventHandler(this.m1_CheckedChanged);
            // 
            // m2
            // 
            this.m2.Appearance = System.Windows.Forms.Appearance.Button;
            this.m2.Location = new System.Drawing.Point(56, 77);
            this.m2.MinimumSize = new System.Drawing.Size(44, 0);
            this.m2.Name = "m2";
            this.m2.Size = new System.Drawing.Size(44, 23);
            this.m2.TabIndex = 8;
            this.m2.TabStop = true;
            this.m2.Tag = "7";
            this.m2.Text = "2ms";
            this.m2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.m2.UseVisualStyleBackColor = true;
            this.m2.CheckedChanged += new System.EventHandler(this.m2_CheckedChanged);
            // 
            // m5
            // 
            this.m5.Appearance = System.Windows.Forms.Appearance.Button;
            this.m5.Location = new System.Drawing.Point(6, 77);
            this.m5.MinimumSize = new System.Drawing.Size(44, 0);
            this.m5.Name = "m5";
            this.m5.Size = new System.Drawing.Size(44, 23);
            this.m5.TabIndex = 7;
            this.m5.TabStop = true;
            this.m5.Tag = "6";
            this.m5.Text = "5ms";
            this.m5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.m5.UseVisualStyleBackColor = true;
            this.m5.CheckedChanged += new System.EventHandler(this.m5_CheckedChanged);
            // 
            // m10
            // 
            this.m10.Appearance = System.Windows.Forms.Appearance.Button;
            this.m10.Location = new System.Drawing.Point(106, 48);
            this.m10.MinimumSize = new System.Drawing.Size(44, 0);
            this.m10.Name = "m10";
            this.m10.Size = new System.Drawing.Size(44, 23);
            this.m10.TabIndex = 6;
            this.m10.TabStop = true;
            this.m10.Tag = "5";
            this.m10.Text = "10ms";
            this.m10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.m10.UseVisualStyleBackColor = true;
            this.m10.CheckedChanged += new System.EventHandler(this.m10_CheckedChanged);
            // 
            // m20
            // 
            this.m20.Appearance = System.Windows.Forms.Appearance.Button;
            this.m20.Location = new System.Drawing.Point(56, 48);
            this.m20.MinimumSize = new System.Drawing.Size(44, 0);
            this.m20.Name = "m20";
            this.m20.Size = new System.Drawing.Size(44, 23);
            this.m20.TabIndex = 5;
            this.m20.TabStop = true;
            this.m20.Tag = "4";
            this.m20.Text = "20ms";
            this.m20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.m20.UseVisualStyleBackColor = true;
            this.m20.CheckedChanged += new System.EventHandler(this.m20_CheckedChanged);
            // 
            // m50
            // 
            this.m50.Appearance = System.Windows.Forms.Appearance.Button;
            this.m50.Location = new System.Drawing.Point(6, 48);
            this.m50.MinimumSize = new System.Drawing.Size(44, 0);
            this.m50.Name = "m50";
            this.m50.Size = new System.Drawing.Size(44, 23);
            this.m50.TabIndex = 4;
            this.m50.TabStop = true;
            this.m50.Tag = "3";
            this.m50.Text = "50ms";
            this.m50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.m50.UseVisualStyleBackColor = true;
            this.m50.CheckedChanged += new System.EventHandler(this.m50_CheckedChanged);
            // 
            // m100
            // 
            this.m100.Appearance = System.Windows.Forms.Appearance.Button;
            this.m100.Location = new System.Drawing.Point(106, 19);
            this.m100.MinimumSize = new System.Drawing.Size(44, 0);
            this.m100.Name = "m100";
            this.m100.Size = new System.Drawing.Size(44, 23);
            this.m100.TabIndex = 3;
            this.m100.TabStop = true;
            this.m100.Tag = "2";
            this.m100.Text = "100ms";
            this.m100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.m100.UseVisualStyleBackColor = true;
            this.m100.CheckedChanged += new System.EventHandler(this.m100_CheckedChanged);
            // 
            // m200
            // 
            this.m200.Appearance = System.Windows.Forms.Appearance.Button;
            this.m200.Location = new System.Drawing.Point(56, 19);
            this.m200.MinimumSize = new System.Drawing.Size(44, 0);
            this.m200.Name = "m200";
            this.m200.Size = new System.Drawing.Size(44, 23);
            this.m200.TabIndex = 2;
            this.m200.TabStop = true;
            this.m200.Tag = "1";
            this.m200.Text = "200ms";
            this.m200.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.m200.UseVisualStyleBackColor = true;
            this.m200.CheckedChanged += new System.EventHandler(this.m200_CheckedChanged);
            // 
            // m500
            // 
            this.m500.Appearance = System.Windows.Forms.Appearance.Button;
            this.m500.Location = new System.Drawing.Point(6, 19);
            this.m500.MinimumSize = new System.Drawing.Size(44, 0);
            this.m500.Name = "m500";
            this.m500.Size = new System.Drawing.Size(44, 23);
            this.m500.TabIndex = 1;
            this.m500.TabStop = true;
            this.m500.Tag = "0";
            this.m500.Text = "500ms";
            this.m500.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.m500.UseVisualStyleBackColor = true;
            this.m500.CheckedChanged += new System.EventHandler(this.m500_CheckedChanged);
            // 
            // RadioButton23
            // 
            this.RadioButton23.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton23.AutoSize = true;
            this.RadioButton23.Location = new System.Drawing.Point(56, 19);
            this.RadioButton23.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton23.Name = "RadioButton23";
            this.RadioButton23.Size = new System.Drawing.Size(45, 23);
            this.RadioButton23.TabIndex = 2;
            this.RadioButton23.TabStop = true;
            this.RadioButton23.Tag = "0";
            this.RadioButton23.Text = "Down";
            this.RadioButton23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton23.UseVisualStyleBackColor = true;
            this.RadioButton23.CheckedChanged += new System.EventHandler(this.RadioButton23_CheckedChanged);
            // 
            // TrackBar3
            // 
            this.TrackBar3.AutoSize = false;
            this.TrackBar3.LargeChange = 16;
            this.TrackBar3.Location = new System.Drawing.Point(506, 248);
            this.TrackBar3.Maximum = 254;
            this.TrackBar3.Name = "TrackBar3";
            this.TrackBar3.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.TrackBar3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TrackBar3.Size = new System.Drawing.Size(30, 143);
            this.TrackBar3.TabIndex = 51;
            this.TrackBar3.TickFrequency = 32;
            this.TrackBar3.Value = 128;
            this.TrackBar3.Scroll += new System.EventHandler(this.TrackBar3_Scroll);
            // 
            // RadioButton21
            // 
            this.RadioButton21.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton21.AutoSize = true;
            this.RadioButton21.Location = new System.Drawing.Point(6, 19);
            this.RadioButton21.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton21.Name = "RadioButton21";
            this.RadioButton21.Size = new System.Drawing.Size(44, 23);
            this.RadioButton21.TabIndex = 1;
            this.RadioButton21.TabStop = true;
            this.RadioButton21.Tag = "1";
            this.RadioButton21.Text = "On";
            this.RadioButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton21.UseVisualStyleBackColor = true;
            this.RadioButton21.CheckedChanged += new System.EventHandler(this.RadioButton21_CheckedChanged);
            // 
            // RadioButton24
            // 
            this.RadioButton24.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton24.AutoSize = true;
            this.RadioButton24.Location = new System.Drawing.Point(6, 19);
            this.RadioButton24.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton24.Name = "RadioButton24";
            this.RadioButton24.Size = new System.Drawing.Size(44, 23);
            this.RadioButton24.TabIndex = 1;
            this.RadioButton24.TabStop = true;
            this.RadioButton24.Tag = "1";
            this.RadioButton24.Text = "Up";
            this.RadioButton24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton24.UseVisualStyleBackColor = true;
            this.RadioButton24.CheckedChanged += new System.EventHandler(this.RadioButton24_CheckedChanged);
            // 
            // RadioButton20
            // 
            this.RadioButton20.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton20.AutoSize = true;
            this.RadioButton20.Location = new System.Drawing.Point(56, 19);
            this.RadioButton20.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton20.Name = "RadioButton20";
            this.RadioButton20.Size = new System.Drawing.Size(44, 23);
            this.RadioButton20.TabIndex = 2;
            this.RadioButton20.TabStop = true;
            this.RadioButton20.Tag = "0";
            this.RadioButton20.Text = "Off";
            this.RadioButton20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton20.UseVisualStyleBackColor = true;
            this.RadioButton20.CheckedChanged += new System.EventHandler(this.RadioButton20_CheckedChanged);
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(503, 388);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(33, 13);
            this.Label3.TabIndex = 54;
            this.Label3.Text = "Level";
            // 
            // RadioButton16
            // 
            this.RadioButton16.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton16.AutoSize = true;
            this.RadioButton16.Location = new System.Drawing.Point(106, 19);
            this.RadioButton16.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton16.Name = "RadioButton16";
            this.RadioButton16.Size = new System.Drawing.Size(44, 23);
            this.RadioButton16.TabIndex = 3;
            this.RadioButton16.TabStop = true;
            this.RadioButton16.Tag = "2";
            this.RadioButton16.Text = "GND";
            this.RadioButton16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton16.UseVisualStyleBackColor = true;
            this.RadioButton16.CheckedChanged += new System.EventHandler(this.RadioButton16_CheckedChanged);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(370, 388);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(44, 13);
            this.Label2.TabIndex = 53;
            this.Label2.Text = "Position";
            // 
            // RadioButton15
            // 
            this.RadioButton15.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton15.AutoSize = true;
            this.RadioButton15.Location = new System.Drawing.Point(6, 19);
            this.RadioButton15.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton15.Name = "RadioButton15";
            this.RadioButton15.Size = new System.Drawing.Size(44, 23);
            this.RadioButton15.TabIndex = 1;
            this.RadioButton15.TabStop = true;
            this.RadioButton15.Tag = "0";
            this.RadioButton15.Text = "AC";
            this.RadioButton15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton15.UseVisualStyleBackColor = true;
            this.RadioButton15.CheckedChanged += new System.EventHandler(this.RadioButton15_CheckedChanged);
            // 
            // RadioButton17
            // 
            this.RadioButton17.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton17.AutoSize = true;
            this.RadioButton17.Location = new System.Drawing.Point(56, 19);
            this.RadioButton17.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton17.Name = "RadioButton17";
            this.RadioButton17.Size = new System.Drawing.Size(44, 23);
            this.RadioButton17.TabIndex = 2;
            this.RadioButton17.TabStop = true;
            this.RadioButton17.Tag = "1";
            this.RadioButton17.Text = "DC";
            this.RadioButton17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton17.UseVisualStyleBackColor = true;
            this.RadioButton17.CheckedChanged += new System.EventHandler(this.RadioButton17_CheckedChanged);
            // 
            // RadioButton18
            // 
            this.RadioButton18.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton18.AutoSize = true;
            this.RadioButton18.Location = new System.Drawing.Point(6, 19);
            this.RadioButton18.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton18.Name = "RadioButton18";
            this.RadioButton18.Size = new System.Drawing.Size(44, 23);
            this.RadioButton18.TabIndex = 1;
            this.RadioButton18.TabStop = true;
            this.RadioButton18.Tag = "0";
            this.RadioButton18.Text = "AC";
            this.RadioButton18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton18.UseVisualStyleBackColor = true;
            this.RadioButton18.CheckedChanged += new System.EventHandler(this.RadioButton18_CheckedChanged);
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.RadioButton20);
            this.GroupBox2.Controls.Add(this.RadioButton21);
            this.GroupBox2.Location = new System.Drawing.Point(542, 248);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(156, 47);
            this.GroupBox2.TabIndex = 48;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Trigger";
            // 
            // TrackBar2
            // 
            this.TrackBar2.AutoSize = false;
            this.TrackBar2.LargeChange = 16;
            this.TrackBar2.Location = new System.Drawing.Point(377, 248);
            this.TrackBar2.Maximum = 127;
            this.TrackBar2.Minimum = -128;
            this.TrackBar2.Name = "TrackBar2";
            this.TrackBar2.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.TrackBar2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TrackBar2.Size = new System.Drawing.Size(30, 143);
            this.TrackBar2.TabIndex = 47;
            this.TrackBar2.TickFrequency = 32;
            this.TrackBar2.Scroll += new System.EventHandler(this.TrackBar2_Scroll);
            // 
            // TrackBar1
            // 
            this.TrackBar1.AutoSize = false;
            this.TrackBar1.LargeChange = 16;
            this.TrackBar1.Location = new System.Drawing.Point(12, 257);
            this.TrackBar1.Maximum = 127;
            this.TrackBar1.Minimum = -128;
            this.TrackBar1.Name = "TrackBar1";
            this.TrackBar1.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.TrackBar1.Size = new System.Drawing.Size(30, 143);
            this.TrackBar1.TabIndex = 46;
            this.TrackBar1.TickFrequency = 32;
            this.TrackBar1.Scroll += new System.EventHandler(this.TrackBar1_Scroll);
            // 
            // GroupBox7
            // 
            this.GroupBox7.Controls.Add(this.RadioButton13);
            this.GroupBox7.Controls.Add(this.RadioButton14);
            this.GroupBox7.Controls.Add(this.RadioButton15);
            this.GroupBox7.Location = new System.Drawing.Point(214, 339);
            this.GroupBox7.Name = "GroupBox7";
            this.GroupBox7.Size = new System.Drawing.Size(157, 52);
            this.GroupBox7.TabIndex = 45;
            this.GroupBox7.TabStop = false;
            this.GroupBox7.Text = "Coupling";
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.RadioButton19);
            this.GroupBox3.Controls.Add(this.RadioButton22);
            this.GroupBox3.Location = new System.Drawing.Point(542, 296);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(156, 47);
            this.GroupBox3.TabIndex = 49;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "Source";
            // 
            // TextBox1
            // 
            this.TextBox1.Location = new System.Drawing.Point(47, 24);
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new System.Drawing.Size(99, 20);
            this.TextBox1.TabIndex = 0;
            this.TextBox1.Text = "500";
            // 
            // GroupBox8
            // 
            this.GroupBox8.Controls.Add(this.RadioButton23);
            this.GroupBox8.Controls.Add(this.RadioButton24);
            this.GroupBox8.Location = new System.Drawing.Point(542, 344);
            this.GroupBox8.Name = "GroupBox8";
            this.GroupBox8.Size = new System.Drawing.Size(156, 47);
            this.GroupBox8.TabIndex = 50;
            this.GroupBox8.TabStop = false;
            this.GroupBox8.Text = "Edge";
            // 
            // GroupBox6
            // 
            this.GroupBox6.Controls.Add(this.RadioButton16);
            this.GroupBox6.Controls.Add(this.RadioButton17);
            this.GroupBox6.Controls.Add(this.RadioButton18);
            this.GroupBox6.Location = new System.Drawing.Point(51, 339);
            this.GroupBox6.Name = "GroupBox6";
            this.GroupBox6.Size = new System.Drawing.Size(157, 52);
            this.GroupBox6.TabIndex = 44;
            this.GroupBox6.TabStop = false;
            this.GroupBox6.Text = "Coupling";
            // 
            // GroupBox5
            // 
            this.GroupBox5.Controls.Add(this.RadioButton7);
            this.GroupBox5.Controls.Add(this.RadioButton8);
            this.GroupBox5.Controls.Add(this.RadioButton9);
            this.GroupBox5.Controls.Add(this.RadioButton10);
            this.GroupBox5.Controls.Add(this.RadioButton11);
            this.GroupBox5.Controls.Add(this.RadioButton12);
            this.GroupBox5.Location = new System.Drawing.Point(214, 248);
            this.GroupBox5.Name = "GroupBox5";
            this.GroupBox5.Size = new System.Drawing.Size(157, 88);
            this.GroupBox5.TabIndex = 43;
            this.GroupBox5.TabStop = false;
            this.GroupBox5.Text = "CH2  Volt/Div";
            // 
            // RadioButton8
            // 
            this.RadioButton8.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton8.AutoSize = true;
            this.RadioButton8.Location = new System.Drawing.Point(56, 48);
            this.RadioButton8.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton8.Name = "RadioButton8";
            this.RadioButton8.Size = new System.Drawing.Size(44, 23);
            this.RadioButton8.TabIndex = 5;
            this.RadioButton8.TabStop = true;
            this.RadioButton8.Tag = "4";
            this.RadioButton8.Text = "30mV";
            this.RadioButton8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton8.UseVisualStyleBackColor = true;
            this.RadioButton8.CheckedChanged += new System.EventHandler(this.RadioButton8_CheckedChanged);
            // 
            // RadioButton9
            // 
            this.RadioButton9.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton9.AutoSize = true;
            this.RadioButton9.Location = new System.Drawing.Point(6, 48);
            this.RadioButton9.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton9.Name = "RadioButton9";
            this.RadioButton9.Size = new System.Drawing.Size(44, 23);
            this.RadioButton9.TabIndex = 4;
            this.RadioButton9.TabStop = true;
            this.RadioButton9.Tag = "3";
            this.RadioButton9.Text = "0.1V";
            this.RadioButton9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton9.UseVisualStyleBackColor = true;
            this.RadioButton9.CheckedChanged += new System.EventHandler(this.RadioButton9_CheckedChanged);
            // 
            // RadioButton10
            // 
            this.RadioButton10.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton10.AutoSize = true;
            this.RadioButton10.Location = new System.Drawing.Point(106, 19);
            this.RadioButton10.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton10.Name = "RadioButton10";
            this.RadioButton10.Size = new System.Drawing.Size(44, 23);
            this.RadioButton10.TabIndex = 3;
            this.RadioButton10.TabStop = true;
            this.RadioButton10.Tag = "2";
            this.RadioButton10.Text = "0.3V";
            this.RadioButton10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton10.UseVisualStyleBackColor = true;
            this.RadioButton10.CheckedChanged += new System.EventHandler(this.RadioButton10_CheckedChanged);
            // 
            // RadioButton11
            // 
            this.RadioButton11.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton11.AutoSize = true;
            this.RadioButton11.Location = new System.Drawing.Point(56, 19);
            this.RadioButton11.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton11.Name = "RadioButton11";
            this.RadioButton11.Size = new System.Drawing.Size(44, 23);
            this.RadioButton11.TabIndex = 2;
            this.RadioButton11.TabStop = true;
            this.RadioButton11.Tag = "1";
            this.RadioButton11.Text = "1V";
            this.RadioButton11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton11.UseVisualStyleBackColor = true;
            this.RadioButton11.CheckedChanged += new System.EventHandler(this.RadioButton11_CheckedChanged);
            // 
            // RadioButton12
            // 
            this.RadioButton12.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton12.AutoSize = true;
            this.RadioButton12.Location = new System.Drawing.Point(6, 19);
            this.RadioButton12.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton12.Name = "RadioButton12";
            this.RadioButton12.Size = new System.Drawing.Size(44, 23);
            this.RadioButton12.TabIndex = 1;
            this.RadioButton12.TabStop = true;
            this.RadioButton12.Tag = "0";
            this.RadioButton12.Text = "3V";
            this.RadioButton12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton12.UseVisualStyleBackColor = true;
            this.RadioButton12.CheckedChanged += new System.EventHandler(this.RadioButton12_CheckedChanged);
            // 
            // Button8
            // 
            this.Button8.Location = new System.Drawing.Point(312, 217);
            this.Button8.Name = "Button8";
            this.Button8.Size = new System.Drawing.Size(109, 25);
            this.Button8.TabIndex = 39;
            this.Button8.Text = "Read Data";
            this.Button8.UseVisualStyleBackColor = true;
            this.Button8.Click += new System.EventHandler(this.Button8_Click);
            // 
            // GroupBox4
            // 
            this.GroupBox4.Controls.Add(this.Label11);
            this.GroupBox4.Controls.Add(this.Label17);
            this.GroupBox4.Controls.Add(this.TextBox7);
            this.GroupBox4.Controls.Add(this.Label15);
            this.GroupBox4.Controls.Add(this.Label16);
            this.GroupBox4.Controls.Add(this.TextBox6);
            this.GroupBox4.Controls.Add(this.Label13);
            this.GroupBox4.Controls.Add(this.Label14);
            this.GroupBox4.Controls.Add(this.TextBox5);
            this.GroupBox4.Controls.Add(this.Label12);
            this.GroupBox4.Controls.Add(this.TextBox4);
            this.GroupBox4.Controls.Add(this.RadioButton47);
            this.GroupBox4.Controls.Add(this.RadioButton46);
            this.GroupBox4.Controls.Add(this.RadioButton45);
            this.GroupBox4.Controls.Add(this.RadioButton44);
            this.GroupBox4.Controls.Add(this.RadioButton43);
            this.GroupBox4.Controls.Add(this.RadioButton42);
            this.GroupBox4.Controls.Add(this.Label9);
            this.GroupBox4.Controls.Add(this.Label10);
            this.GroupBox4.Controls.Add(this.TextBox3);
            this.GroupBox4.Controls.Add(this.Label7);
            this.GroupBox4.Controls.Add(this.Label8);
            this.GroupBox4.Controls.Add(this.TextBox2);
            this.GroupBox4.Controls.Add(this.Label6);
            this.GroupBox4.Controls.Add(this.Label5);
            this.GroupBox4.Controls.Add(this.TextBox1);
            this.GroupBox4.Location = new System.Drawing.Point(704, 13);
            this.GroupBox4.Name = "GroupBox4";
            this.GroupBox4.Size = new System.Drawing.Size(194, 378);
            this.GroupBox4.TabIndex = 42;
            this.GroupBox4.TabStop = false;
            this.GroupBox4.Text = "Function Generator";
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Location = new System.Drawing.Point(152, 327);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(26, 13);
            this.Label11.TabIndex = 26;
            this.Label11.Text = "Sec";
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.Location = new System.Drawing.Point(10, 328);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(30, 13);
            this.Label17.TabIndex = 25;
            this.Label17.Text = "Time";
            // 
            // TextBox7
            // 
            this.TextBox7.Location = new System.Drawing.Point(47, 324);
            this.TextBox7.Name = "TextBox7";
            this.TextBox7.Size = new System.Drawing.Size(99, 20);
            this.TextBox7.TabIndex = 24;
            this.TextBox7.Text = "20";
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Location = new System.Drawing.Point(152, 302);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(20, 13);
            this.Label15.TabIndex = 23;
            this.Label15.Text = "Hz";
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.Location = new System.Drawing.Point(10, 303);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(29, 13);
            this.Label16.TabIndex = 22;
            this.Label16.Text = "Stop";
            // 
            // TextBox6
            // 
            this.TextBox6.Location = new System.Drawing.Point(47, 299);
            this.TextBox6.Name = "TextBox6";
            this.TextBox6.Size = new System.Drawing.Size(99, 20);
            this.TextBox6.TabIndex = 21;
            this.TextBox6.Text = "50000";
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Location = new System.Drawing.Point(152, 276);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(20, 13);
            this.Label13.TabIndex = 20;
            this.Label13.Text = "Hz";
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Location = new System.Drawing.Point(10, 277);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(29, 13);
            this.Label14.TabIndex = 19;
            this.Label14.Text = "Start";
            // 
            // TextBox5
            // 
            this.TextBox5.Location = new System.Drawing.Point(47, 273);
            this.TextBox5.Name = "TextBox5";
            this.TextBox5.Size = new System.Drawing.Size(99, 20);
            this.TextBox5.TabIndex = 18;
            this.TextBox5.Text = "500";
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Location = new System.Drawing.Point(10, 222);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(23, 13);
            this.Label12.TabIndex = 16;
            this.Label12.Text = "File";
            // 
            // TextBox4
            // 
            this.TextBox4.Location = new System.Drawing.Point(47, 218);
            this.TextBox4.Name = "TextBox4";
            this.TextBox4.Size = new System.Drawing.Size(99, 20);
            this.TextBox4.TabIndex = 15;
            this.TextBox4.Text = "damp_wav.lib";
            // 
            // RadioButton47
            // 
            this.RadioButton47.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton47.Location = new System.Drawing.Point(47, 350);
            this.RadioButton47.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton47.Name = "RadioButton47";
            this.RadioButton47.Size = new System.Drawing.Size(99, 23);
            this.RadioButton47.TabIndex = 14;
            this.RadioButton47.TabStop = true;
            this.RadioButton47.Tag = "0";
            this.RadioButton47.Text = "Stop";
            this.RadioButton47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton47.UseVisualStyleBackColor = true;
            this.RadioButton47.CheckedChanged += new System.EventHandler(this.RadioButton47_CheckedChanged);
            // 
            // RadioButton46
            // 
            this.RadioButton46.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton46.Location = new System.Drawing.Point(47, 244);
            this.RadioButton46.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton46.Name = "RadioButton46";
            this.RadioButton46.Size = new System.Drawing.Size(99, 23);
            this.RadioButton46.TabIndex = 13;
            this.RadioButton46.TabStop = true;
            this.RadioButton46.Tag = "0";
            this.RadioButton46.Text = "Sweep";
            this.RadioButton46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton46.UseVisualStyleBackColor = true;
            this.RadioButton46.CheckedChanged += new System.EventHandler(this.RadioButton46_CheckedChanged);
            // 
            // RadioButton45
            // 
            this.RadioButton45.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton45.Location = new System.Drawing.Point(47, 189);
            this.RadioButton45.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton45.Name = "RadioButton45";
            this.RadioButton45.Size = new System.Drawing.Size(99, 23);
            this.RadioButton45.TabIndex = 12;
            this.RadioButton45.TabStop = true;
            this.RadioButton45.Tag = "0";
            this.RadioButton45.Text = "Library";
            this.RadioButton45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton45.UseVisualStyleBackColor = true;
            this.RadioButton45.CheckedChanged += new System.EventHandler(this.RadioButton45_CheckedChanged);
            // 
            // RadioButton44
            // 
            this.RadioButton44.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton44.Location = new System.Drawing.Point(47, 160);
            this.RadioButton44.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton44.Name = "RadioButton44";
            this.RadioButton44.Size = new System.Drawing.Size(99, 23);
            this.RadioButton44.TabIndex = 11;
            this.RadioButton44.TabStop = true;
            this.RadioButton44.Tag = "0";
            this.RadioButton44.Text = "Triangle";
            this.RadioButton44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton44.UseVisualStyleBackColor = true;
            this.RadioButton44.CheckedChanged += new System.EventHandler(this.RadioButton44_CheckedChanged);
            // 
            // RadioButton43
            // 
            this.RadioButton43.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton43.Location = new System.Drawing.Point(47, 131);
            this.RadioButton43.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton43.Name = "RadioButton43";
            this.RadioButton43.Size = new System.Drawing.Size(99, 23);
            this.RadioButton43.TabIndex = 10;
            this.RadioButton43.TabStop = true;
            this.RadioButton43.Tag = "0";
            this.RadioButton43.Text = "Square";
            this.RadioButton43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton43.UseVisualStyleBackColor = true;
            this.RadioButton43.CheckedChanged += new System.EventHandler(this.RadioButton43_CheckedChanged);
            // 
            // RadioButton42
            // 
            this.RadioButton42.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton42.Location = new System.Drawing.Point(47, 102);
            this.RadioButton42.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton42.Name = "RadioButton42";
            this.RadioButton42.Size = new System.Drawing.Size(99, 23);
            this.RadioButton42.TabIndex = 9;
            this.RadioButton42.TabStop = true;
            this.RadioButton42.Tag = "0";
            this.RadioButton42.Text = "Sine";
            this.RadioButton42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton42.UseVisualStyleBackColor = true;
            this.RadioButton42.CheckedChanged += new System.EventHandler(this.RadioButton42_CheckedChanged);
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(152, 79);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(14, 13);
            this.Label9.TabIndex = 8;
            this.Label9.Text = "V";
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Location = new System.Drawing.Point(10, 80);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(29, 13);
            this.Label10.TabIndex = 7;
            this.Label10.Text = "Offs.";
            // 
            // TextBox3
            // 
            this.TextBox3.Location = new System.Drawing.Point(47, 76);
            this.TextBox3.Name = "TextBox3";
            this.TextBox3.Size = new System.Drawing.Size(99, 20);
            this.TextBox3.TabIndex = 6;
            this.TextBox3.Text = "0";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(152, 53);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(26, 13);
            this.Label7.TabIndex = 5;
            this.Label7.Text = "Vpp";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(10, 54);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(33, 13);
            this.Label8.TabIndex = 4;
            this.Label8.Text = "Ampl.";
            // 
            // TextBox2
            // 
            this.TextBox2.Location = new System.Drawing.Point(47, 50);
            this.TextBox2.Name = "TextBox2";
            this.TextBox2.Size = new System.Drawing.Size(99, 20);
            this.TextBox2.TabIndex = 3;
            this.TextBox2.Text = "5";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(152, 27);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(20, 13);
            this.Label6.TabIndex = 2;
            this.Label6.Text = "Hz";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(10, 28);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(31, 13);
            this.Label5.TabIndex = 1;
            this.Label5.Text = "Freq.";
            // 
            // Button1
            // 
            this.Button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button1.Location = new System.Drawing.Point(427, 12);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(109, 25);
            this.Button1.TabIndex = 30;
            this.Button1.Text = "Start PCSGU250";
            this.Button1.UseVisualStyleBackColor = true;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // RadioButton6
            // 
            this.RadioButton6.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton6.AutoSize = true;
            this.RadioButton6.Location = new System.Drawing.Point(106, 48);
            this.RadioButton6.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton6.Name = "RadioButton6";
            this.RadioButton6.Size = new System.Drawing.Size(44, 23);
            this.RadioButton6.TabIndex = 6;
            this.RadioButton6.TabStop = true;
            this.RadioButton6.Tag = "5";
            this.RadioButton6.Text = "10mV";
            this.RadioButton6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton6.UseVisualStyleBackColor = true;
            this.RadioButton6.CheckedChanged += new System.EventHandler(this.RadioButton6_CheckedChanged);
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.RadioButton6);
            this.GroupBox1.Controls.Add(this.RadioButton5);
            this.GroupBox1.Controls.Add(this.RadioButton4);
            this.GroupBox1.Controls.Add(this.RadioButton3);
            this.GroupBox1.Controls.Add(this.RadioButton2);
            this.GroupBox1.Controls.Add(this.RadioButton1);
            this.GroupBox1.Location = new System.Drawing.Point(51, 248);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(157, 88);
            this.GroupBox1.TabIndex = 41;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "CH1  Volt/Div";
            // 
            // RadioButton5
            // 
            this.RadioButton5.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton5.AutoSize = true;
            this.RadioButton5.Location = new System.Drawing.Point(56, 48);
            this.RadioButton5.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton5.Name = "RadioButton5";
            this.RadioButton5.Size = new System.Drawing.Size(44, 23);
            this.RadioButton5.TabIndex = 5;
            this.RadioButton5.TabStop = true;
            this.RadioButton5.Tag = "4";
            this.RadioButton5.Text = "30mV";
            this.RadioButton5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton5.UseVisualStyleBackColor = true;
            this.RadioButton5.CheckedChanged += new System.EventHandler(this.RadioButton5_CheckedChanged);
            // 
            // RadioButton4
            // 
            this.RadioButton4.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton4.AutoSize = true;
            this.RadioButton4.Location = new System.Drawing.Point(6, 48);
            this.RadioButton4.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton4.Name = "RadioButton4";
            this.RadioButton4.Size = new System.Drawing.Size(44, 23);
            this.RadioButton4.TabIndex = 4;
            this.RadioButton4.TabStop = true;
            this.RadioButton4.Tag = "3";
            this.RadioButton4.Text = "0.1V";
            this.RadioButton4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton4.UseVisualStyleBackColor = true;
            this.RadioButton4.CheckedChanged += new System.EventHandler(this.RadioButton4_CheckedChanged);
            // 
            // RadioButton3
            // 
            this.RadioButton3.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton3.AutoSize = true;
            this.RadioButton3.Location = new System.Drawing.Point(106, 19);
            this.RadioButton3.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton3.Name = "RadioButton3";
            this.RadioButton3.Size = new System.Drawing.Size(44, 23);
            this.RadioButton3.TabIndex = 3;
            this.RadioButton3.TabStop = true;
            this.RadioButton3.Tag = "2";
            this.RadioButton3.Text = "0.3V";
            this.RadioButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton3.UseVisualStyleBackColor = true;
            this.RadioButton3.CheckedChanged += new System.EventHandler(this.RadioButton3_CheckedChanged);
            // 
            // RadioButton2
            // 
            this.RadioButton2.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton2.AutoSize = true;
            this.RadioButton2.Location = new System.Drawing.Point(56, 19);
            this.RadioButton2.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton2.Name = "RadioButton2";
            this.RadioButton2.Size = new System.Drawing.Size(44, 23);
            this.RadioButton2.TabIndex = 2;
            this.RadioButton2.TabStop = true;
            this.RadioButton2.Tag = "1";
            this.RadioButton2.Text = "1V";
            this.RadioButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton2.UseVisualStyleBackColor = true;
            this.RadioButton2.CheckedChanged += new System.EventHandler(this.RadioButton2_CheckedChanged);
            // 
            // RadioButton1
            // 
            this.RadioButton1.Appearance = System.Windows.Forms.Appearance.Button;
            this.RadioButton1.AutoSize = true;
            this.RadioButton1.Location = new System.Drawing.Point(6, 19);
            this.RadioButton1.MinimumSize = new System.Drawing.Size(44, 0);
            this.RadioButton1.Name = "RadioButton1";
            this.RadioButton1.Size = new System.Drawing.Size(44, 23);
            this.RadioButton1.TabIndex = 1;
            this.RadioButton1.TabStop = true;
            this.RadioButton1.Tag = "0";
            this.RadioButton1.Text = "3V";
            this.RadioButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RadioButton1.UseVisualStyleBackColor = true;
            this.RadioButton1.CheckedChanged += new System.EventHandler(this.RadioButton1_CheckedChanged);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(128, 223);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(22, 13);
            this.Label1.TabIndex = 40;
            this.Label1.Text = "- - -";
            // 
            // Button7
            // 
            this.Button7.Location = new System.Drawing.Point(189, 217);
            this.Button7.Name = "Button7";
            this.Button7.Size = new System.Drawing.Size(109, 25);
            this.Button7.TabIndex = 38;
            this.Button7.Text = "Get Settings";
            this.Button7.UseVisualStyleBackColor = true;
            this.Button7.Click += new System.EventHandler(this.Button7_Click);
            // 
            // Button4
            // 
            this.Button4.Location = new System.Drawing.Point(427, 115);
            this.Button4.Name = "Button4";
            this.Button4.Size = new System.Drawing.Size(109, 21);
            this.Button4.TabIndex = 33;
            this.Button4.Text = "Hide PCSGU250";
            this.Button4.UseVisualStyleBackColor = true;
            this.Button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // Button3
            // 
            this.Button3.Location = new System.Drawing.Point(427, 88);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(109, 21);
            this.Button3.TabIndex = 32;
            this.Button3.Text = "Show PCSGU250";
            this.Button3.UseVisualStyleBackColor = true;
            this.Button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // Button2
            // 
            this.Button2.Location = new System.Drawing.Point(427, 43);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(109, 25);
            this.Button2.TabIndex = 31;
            this.Button2.Text = "Stop PCSGU250";
            this.Button2.UseVisualStyleBackColor = true;
            this.Button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // CheckBox1
            // 
            this.CheckBox1.Appearance = System.Windows.Forms.Appearance.Button;
            this.CheckBox1.AutoSize = true;
            this.CheckBox1.Enabled = false;
            this.CheckBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckBox1.Location = new System.Drawing.Point(427, 166);
            this.CheckBox1.MinimumSize = new System.Drawing.Size(109, 35);
            this.CheckBox1.Name = "CheckBox1";
            this.CheckBox1.Size = new System.Drawing.Size(109, 35);
            this.CheckBox1.TabIndex = 34;
            this.CheckBox1.Text = "Run";
            this.CheckBox1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.CheckBox1.UseVisualStyleBackColor = true;
            this.CheckBox1.CheckedChanged += new System.EventHandler(this.CheckBox1_CheckedChanged);
            // 
            // Button6
            // 
            this.Button6.Location = new System.Drawing.Point(12, 217);
            this.Button6.Name = "Button6";
            this.Button6.Size = new System.Drawing.Size(109, 25);
            this.Button6.TabIndex = 37;
            this.Button6.Text = "Data Ready?";
            this.Button6.UseVisualStyleBackColor = true;
            this.Button6.Click += new System.EventHandler(this.Button6_Click);
            // 
            // Button5
            // 
            this.Button5.Enabled = false;
            this.Button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button5.Location = new System.Drawing.Point(427, 207);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(109, 35);
            this.Button5.TabIndex = 35;
            this.Button5.Text = "Single";
            this.Button5.UseVisualStyleBackColor = true;
            this.Button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // ListBox1
            // 
            this.ListBox1.FormattingEnabled = true;
            this.ListBox1.Location = new System.Drawing.Point(12, 12);
            this.ListBox1.Name = "ListBox1";
            this.ListBox1.Size = new System.Drawing.Size(409, 199);
            this.ListBox1.TabIndex = 36;
            this.ListBox1.SelectedIndexChanged += new System.EventHandler(this.ListBox1_SelectedIndexChanged);
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(5, 388);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(44, 13);
            this.Label4.TabIndex = 55;
            this.Label4.Text = "Position";
            // 
            // VellemanForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(901, 405);
            this.Controls.Add(this.GroupBox9);
            this.Controls.Add(this.TrackBar3);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.TrackBar2);
            this.Controls.Add(this.TrackBar1);
            this.Controls.Add(this.GroupBox7);
            this.Controls.Add(this.GroupBox3);
            this.Controls.Add(this.GroupBox8);
            this.Controls.Add(this.GroupBox6);
            this.Controls.Add(this.GroupBox5);
            this.Controls.Add(this.Button8);
            this.Controls.Add(this.GroupBox4);
            this.Controls.Add(this.Button1);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.Button7);
            this.Controls.Add(this.Button4);
            this.Controls.Add(this.Button3);
            this.Controls.Add(this.Button2);
            this.Controls.Add(this.CheckBox1);
            this.Controls.Add(this.Button6);
            this.Controls.Add(this.Button5);
            this.Controls.Add(this.ListBox1);
            this.Controls.Add(this.Label4);
            this.Name = "VellemanForm";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.GroupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.TrackBar3)).EndInit();
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TrackBar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrackBar1)).EndInit();
            this.GroupBox7.ResumeLayout(false);
            this.GroupBox7.PerformLayout();
            this.GroupBox3.ResumeLayout(false);
            this.GroupBox3.PerformLayout();
            this.GroupBox8.ResumeLayout(false);
            this.GroupBox8.PerformLayout();
            this.GroupBox6.ResumeLayout(false);
            this.GroupBox6.PerformLayout();
            this.GroupBox5.ResumeLayout(false);
            this.GroupBox5.PerformLayout();
            this.GroupBox4.ResumeLayout(false);
            this.GroupBox4.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.RadioButton RadioButton13;
        internal System.Windows.Forms.RadioButton RadioButton7;
        internal System.Windows.Forms.RadioButton RadioButton14;
        internal System.Windows.Forms.RadioButton RadioButton19;
        internal System.Windows.Forms.RadioButton RadioButton22;
        internal System.Windows.Forms.GroupBox GroupBox9;
        internal System.Windows.Forms.RadioButton u2;
        internal System.Windows.Forms.RadioButton u5;
        internal System.Windows.Forms.RadioButton u10;
        internal System.Windows.Forms.RadioButton u20;
        internal System.Windows.Forms.RadioButton u50;
        internal System.Windows.Forms.RadioButton m01;
        internal System.Windows.Forms.RadioButton m02;
        internal System.Windows.Forms.RadioButton m05;
        internal System.Windows.Forms.RadioButton m1;
        internal System.Windows.Forms.RadioButton m2;
        internal System.Windows.Forms.RadioButton m5;
        internal System.Windows.Forms.RadioButton m10;
        internal System.Windows.Forms.RadioButton m20;
        internal System.Windows.Forms.RadioButton m50;
        internal System.Windows.Forms.RadioButton m100;
        internal System.Windows.Forms.RadioButton m200;
        internal System.Windows.Forms.RadioButton m500;
        internal System.Windows.Forms.RadioButton RadioButton23;
        internal System.Windows.Forms.TrackBar TrackBar3;
        internal System.Windows.Forms.RadioButton RadioButton21;
        internal System.Windows.Forms.RadioButton RadioButton24;
        internal System.Windows.Forms.RadioButton RadioButton20;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.RadioButton RadioButton16;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.RadioButton RadioButton15;
        internal System.Windows.Forms.RadioButton RadioButton17;
        internal System.Windows.Forms.RadioButton RadioButton18;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.TrackBar TrackBar2;
        internal System.Windows.Forms.TrackBar TrackBar1;
        internal System.Windows.Forms.GroupBox GroupBox7;
        internal System.Windows.Forms.GroupBox GroupBox3;
        internal System.Windows.Forms.TextBox TextBox1;
        internal System.Windows.Forms.GroupBox GroupBox8;
        internal System.Windows.Forms.GroupBox GroupBox6;
        internal System.Windows.Forms.GroupBox GroupBox5;
        internal System.Windows.Forms.RadioButton RadioButton8;
        internal System.Windows.Forms.RadioButton RadioButton9;
        internal System.Windows.Forms.RadioButton RadioButton10;
        internal System.Windows.Forms.RadioButton RadioButton11;
        internal System.Windows.Forms.RadioButton RadioButton12;
        internal System.Windows.Forms.Button Button8;
        internal System.Windows.Forms.GroupBox GroupBox4;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.TextBox TextBox7;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.TextBox TextBox6;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.TextBox TextBox5;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.TextBox TextBox4;
        internal System.Windows.Forms.RadioButton RadioButton47;
        internal System.Windows.Forms.RadioButton RadioButton46;
        internal System.Windows.Forms.RadioButton RadioButton45;
        internal System.Windows.Forms.RadioButton RadioButton44;
        internal System.Windows.Forms.RadioButton RadioButton43;
        internal System.Windows.Forms.RadioButton RadioButton42;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.TextBox TextBox3;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.TextBox TextBox2;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Button Button1;
        internal System.Windows.Forms.RadioButton RadioButton6;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.RadioButton RadioButton5;
        internal System.Windows.Forms.RadioButton RadioButton4;
        internal System.Windows.Forms.RadioButton RadioButton3;
        internal System.Windows.Forms.RadioButton RadioButton2;
        internal System.Windows.Forms.RadioButton RadioButton1;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Button Button7;
        internal System.Windows.Forms.Button Button4;
        internal System.Windows.Forms.Button Button3;
        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.CheckBox CheckBox1;
        internal System.Windows.Forms.Button Button6;
        internal System.Windows.Forms.Button Button5;
        internal System.Windows.Forms.ListBox ListBox1;
        internal System.Windows.Forms.Label Label4;
    }
}

