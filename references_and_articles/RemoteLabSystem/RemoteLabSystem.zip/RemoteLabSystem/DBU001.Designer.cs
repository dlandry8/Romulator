﻿namespace RemoteLabSystem
{
    partial class DBU001
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DBU001));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.TP4 = new System.Windows.Forms.Button();
            this.TP5 = new System.Windows.Forms.Button();
            this.TP6 = new System.Windows.Forms.Button();
            this.TP3 = new System.Windows.Forms.Button();
            this.TP2 = new System.Windows.Forms.Button();
            this.TP1 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.comboBox_o1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox_o2 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox_fg = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.textbox_send = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textbox_receive = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(143, 50);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(651, 406);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 433);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Open Velleman";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 417);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Launch Velleman Form";
            // 
            // TP4
            // 
            this.TP4.BackColor = System.Drawing.Color.Black;
            this.TP4.Location = new System.Drawing.Point(275, 240);
            this.TP4.Name = "TP4";
            this.TP4.Size = new System.Drawing.Size(20, 20);
            this.TP4.TabIndex = 3;
            this.TP4.UseVisualStyleBackColor = false;
            this.TP4.Click += new System.EventHandler(this.button2_Click);
            // 
            // TP5
            // 
            this.TP5.BackColor = System.Drawing.Color.Black;
            this.TP5.Location = new System.Drawing.Point(548, 240);
            this.TP5.Name = "TP5";
            this.TP5.Size = new System.Drawing.Size(20, 20);
            this.TP5.TabIndex = 4;
            this.TP5.UseVisualStyleBackColor = false;
            // 
            // TP6
            // 
            this.TP6.BackColor = System.Drawing.Color.Black;
            this.TP6.Location = new System.Drawing.Point(699, 215);
            this.TP6.Name = "TP6";
            this.TP6.Size = new System.Drawing.Size(20, 20);
            this.TP6.TabIndex = 5;
            this.TP6.UseVisualStyleBackColor = false;
            // 
            // TP3
            // 
            this.TP3.BackColor = System.Drawing.Color.Black;
            this.TP3.Location = new System.Drawing.Point(548, 197);
            this.TP3.Name = "TP3";
            this.TP3.Size = new System.Drawing.Size(20, 20);
            this.TP3.TabIndex = 8;
            this.TP3.UseVisualStyleBackColor = false;
            // 
            // TP2
            // 
            this.TP2.BackColor = System.Drawing.Color.Black;
            this.TP2.Location = new System.Drawing.Point(428, 215);
            this.TP2.Name = "TP2";
            this.TP2.Size = new System.Drawing.Size(20, 20);
            this.TP2.TabIndex = 7;
            this.TP2.UseVisualStyleBackColor = false;
            // 
            // TP1
            // 
            this.TP1.BackColor = System.Drawing.Color.Black;
            this.TP1.Location = new System.Drawing.Point(245, 197);
            this.TP1.Name = "TP1";
            this.TP1.Size = new System.Drawing.Size(20, 20);
            this.TP1.TabIndex = 6;
            this.TP1.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(143, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(651, 50);
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // comboBox_o1
            // 
            this.comboBox_o1.FormattingEnabled = true;
            this.comboBox_o1.Items.AddRange(new object[] {
            "Test Point 1",
            "Test Point 2",
            "Test Point 3",
            "Test Point 4",
            "Test Point 5",
            "Test Point 6",
            "Test Point 7",
            "Test Point 8"});
            this.comboBox_o1.Location = new System.Drawing.Point(12, 87);
            this.comboBox_o1.Name = "comboBox_o1";
            this.comboBox_o1.Size = new System.Drawing.Size(121, 21);
            this.comboBox_o1.TabIndex = 10;
            this.comboBox_o1.SelectedIndexChanged += new System.EventHandler(this.comboBox_o1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Oscope 1 TP Selector";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Oscope 2 TP Selector";
            // 
            // comboBox_o2
            // 
            this.comboBox_o2.FormattingEnabled = true;
            this.comboBox_o2.Items.AddRange(new object[] {
            "Test Point 1",
            "Test Point 2",
            "Test Point 3",
            "Test Point 4",
            "Test Point 5",
            "Test Point 6",
            "Test Point 7",
            "Test Point 8"});
            this.comboBox_o2.Location = new System.Drawing.Point(12, 142);
            this.comboBox_o2.Name = "comboBox_o2";
            this.comboBox_o2.Size = new System.Drawing.Size(121, 21);
            this.comboBox_o2.TabIndex = 13;
            this.comboBox_o2.SelectedIndexChanged += new System.EventHandler(this.comboBox_o2_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(242, 181);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "TP1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(425, 201);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "TP2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(545, 181);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "TP3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(272, 224);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(27, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "TP4";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.Location = new System.Drawing.Point(545, 224);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 13);
            this.label8.TabIndex = 18;
            this.label8.Text = "TP5";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(696, 238);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(27, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "TP6";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 204);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "FG TP Selector";
            // 
            // comboBox_fg
            // 
            this.comboBox_fg.FormattingEnabled = true;
            this.comboBox_fg.Items.AddRange(new object[] {
            "Test Point 1",
            "Test Point 4",
            "Test Point 2"});
            this.comboBox_fg.Location = new System.Drawing.Point(12, 220);
            this.comboBox_fg.Name = "comboBox_fg";
            this.comboBox_fg.Size = new System.Drawing.Size(121, 21);
            this.comboBox_fg.TabIndex = 21;
            this.comboBox_fg.SelectedIndexChanged += new System.EventHandler(this.comboBox_fg_SelectedIndexChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "0 KΩ",
            "1 KΩ",
            "2 KΩ",
            "3 KΩ",
            "4 KΩ",
            "5 KΩ",
            "6 KΩ",
            "7 KΩ",
            "8 KΩ",
            "9 KΩ",
            "10 KΩ",
            "11 KΩ",
            "12 KΩ",
            "13 KΩ",
            "14 KΩ",
            "15 KΩ"});
            this.comboBox1.Location = new System.Drawing.Point(567, 68);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 22;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(595, 57);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(93, 13);
            this.label11.TabIndex = 23;
            this.label11.Text = "Select Resistance";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            // 
            // textbox_send
            // 
            this.textbox_send.Location = new System.Drawing.Point(193, 485);
            this.textbox_send.Name = "textbox_send";
            this.textbox_send.Size = new System.Drawing.Size(234, 20);
            this.textbox_send.TabIndex = 24;
            this.textbox_send.TextChanged += new System.EventHandler(this.textbox_send_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(190, 463);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 13);
            this.label12.TabIndex = 25;
            this.label12.Text = "SEND";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(526, 463);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 13);
            this.label13.TabIndex = 27;
            this.label13.Text = "RCV";
            // 
            // textbox_receive
            // 
            this.textbox_receive.Location = new System.Drawing.Point(529, 485);
            this.textbox_receive.Name = "textbox_receive";
            this.textbox_receive.Size = new System.Drawing.Size(234, 20);
            this.textbox_receive.TabIndex = 28;
            // 
            // DBU001
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(806, 566);
            this.Controls.Add(this.textbox_receive);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.textbox_send);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.comboBox_fg);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox_o2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox_o1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.TP3);
            this.Controls.Add(this.TP2);
            this.Controls.Add(this.TP1);
            this.Controls.Add(this.TP6);
            this.Controls.Add(this.TP5);
            this.Controls.Add(this.TP4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "DBU001";
            this.Text = "DBU001";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.DBU001_FormClosed);
            this.Load += new System.EventHandler(this.DBU001_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button TP4;
        private System.Windows.Forms.Button TP5;
        private System.Windows.Forms.Button TP6;
        private System.Windows.Forms.Button TP3;
        private System.Windows.Forms.Button TP2;
        private System.Windows.Forms.Button TP1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ComboBox comboBox_o1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox_o2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox_fg;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.TextBox textbox_send;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textbox_receive;
    }
}