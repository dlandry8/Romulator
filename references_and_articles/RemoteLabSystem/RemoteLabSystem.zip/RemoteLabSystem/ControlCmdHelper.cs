﻿using System;
using System.IO.Ports;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using Microsoft.SPOT;

using System.Threading;

namespace RemoteLabSystem
{
    class ControlCmdHelper
    {

    }
}
